﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using AngularJSWebAPI.Models;
using AngularJSWebAPI.Interface;

namespace AngularJSWebAPI.Repositories
{
    public class PersonRepository:IPersonRepository 
    {
        AdventureWorksEntities DB = new AdventureWorksEntities();

        public IEnumerable<Person> GetAll()
        {
            return DB.Person;
        }

        public Person Get(int id)
        {
            return DB.Person.Find(id);
        }

        public Person Add(Person item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }

            DB.Person.Add(item);
            DB.SaveChanges();
            return item;
        }

        public bool Update(Person item)
        {
            if (item == null)
            {
                throw new ArgumentNullException("item");
            }
            var person = DB.Person.Single(a => a.Id == item.Id);

            person.FirstName = item.FirstName;
            person.LastName = item.LastName;
            person.Age = item.Age;
            person.Gender = item.Gender;
            person.City = item.City;
            DB.SaveChanges();
            return true;
        }
        public bool Delete(int id)
        {
            Person item = DB.Person.Find(id);
            DB.Person.Remove(item);
            DB.SaveChanges();
            return true;
        }
    }
}